import React from "react";

const DepositAmount = () => {
  const handleSubmit = () => {};
  const handleChange = () => {};
  return (
    <>
      <div className="text-end px-10 my-4">
        <h2 className="font-medium">Available Balance</h2>
        <div className="text-blue-500 font-bold ">500$</div>
      </div>
      <div className="max-w-screen-sm mx-auto bg-white p-6 rounded-md shadow-md">
        <h1 className="text-2xl font-semibold my-4 text-center">
          Deposit Amount
        </h1>
        <form onSubmit={handleSubmit}>
          <div className="">
            <div className="mb-4">
              <label className="block text-gray-700">Account Type</label>
              <select
                className="w-full border rounded-md py-2 px-3"
                name="accountType"
                onChange={handleChange}
                required
              >
                <option selected disabled>
                  Select Account Type
                </option>
                <option value="Saving">Saving</option>
                <option value="Current">Current</option>
              </select>
            </div>

            <div className="mb-4">
              <label className="block text-gray-700">Deposit Amount</label>
              <input
                type="number"
                className="w-full border rounded-md py-2 px-3"
                name="depositAmount "
                onChange={handleChange}
                required
              />
            </div>

            <div className="mt-6 text-center">
              <button
                type="submit"
                className="bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600"
              >
                Deposit
              </button>
            </div>
          </div>
        </form>
      </div>
    </>
  );
};

export default DepositAmount;
