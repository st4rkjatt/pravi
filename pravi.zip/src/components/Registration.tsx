import React, { useState } from 'react';

const RegistrationForm = () => {
  const [formData, setFormData] = useState({
    name: '',
    username: '',
    password: '',
    address: '',
    country: '',
    state: '',
    email: '',
    contact: '',
    dob: '',
    accountType: '',
    branchName: '',
    initialDeposit: '',
    proofType: '',
    proofNo: '',
  });
  const handleChange =( e: React.ChangeEvent<HTMLTextAreaElement | HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    // Add your form submission logic here
    console.log(formData);
  };

  return (
    <div className="max-w-md mx-auto bg-white p-6 rounded-md shadow-md">
      <h1 className="text-2xl font-semibold mb-4">User Registration</h1>
      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label htmlFor="name" className="block text-gray-700">Name</label>
          <input type="text" id="name" name="name" className="w-full border rounded-md py-2 px-3" onChange={handleChange} required />
        </div>
        <div className="mb-4">
          <label htmlFor="username" className="block text-gray-700">Username</label>
          <input type="text" id="username" name="username" className="w-full border rounded-md py-2 px-3" onChange={handleChange} required />
        </div>
        <div className="mb-4">
          <label htmlFor="password" className="block text-gray-700">Password</label>
          <input type="password" id="password" name="password" className="w-full border rounded-md py-2 px-3" onChange={handleChange} required />
        </div>
        <div className="mb-4">
          <label htmlFor="address" className="block text-gray-700">Address</label>
          <input type="text" id="address" name="address" className="w-full border rounded-md py-2 px-3" onChange={handleChange} required />
        </div>
   
        <div >
         <label className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
           Select an option
         </label>
         <select
    id="countries"  
    className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
  >
    <option selected disabled>Choose a country</option>
    <option value="US">United States</option>
    <option value="CA">Canada</option>
    <option value="FR">France</option>
    <option value="DE">Germany</option>
         </select>
</div>




        <div className="mb-4">
          <label htmlFor="state" className="block text-gray-700">State</label>
          <input type="text" id="state" name="state" className="w-full border rounded-md py-2 px-3" onChange={handleChange} required />
        </div>
        <div className="mb-4">
          <label htmlFor="email" className="block text-gray-700">Email</label>
          <input type="email" id="email" name="email" className="w-full border rounded-md py-2 px-3" onChange={handleChange} required />
        </div>
        <div className="mb-4">
          <label htmlFor="contact" className="block text-gray-700">Contact</label>
          <input type="text" id="contact" name="contact" className="w-full border rounded-md py-2 px-3" onChange={handleChange} required />
        </div>
        <div className="mb-4">
          <label htmlFor="dob" className="block text-gray-700">Date of Birth</label>
          <input type="text" id="dob" name="dob" className="w-full border rounded-md py-2 px-3" onChange={handleChange} required />
        </div>
        <div className="mb-4">
          <label htmlFor="accountType" className="block text-gray-700">Account Type</label>
          <input type="text" id="accountType" name="accountType" className="w-full border rounded-md py-2 px-3" onChange={handleChange} required />
        </div>
        <div className="mb-4">
          <label htmlFor="branchName" className="block text-gray-700">Branch Name</label>
          <input type="text" id="branchName" name="branchName" className="w-full border rounded-md py-2 px-3" onChange={handleChange} required />
        </div>
        <div className="mb-4">
          <label htmlFor="initialDeposit" className="block text-gray-700">Initial Deposit</label>
          <input type="text" id="initialDeposit" name="initialDeposit" className="w-full border rounded-md py-2 px-3" onChange={handleChange} required />
        </div>
        <div className="mb-4">
          <label htmlFor="proofType" className="block text-gray-700">Proof Type</label>
          <input type="text" id="proofType" name="proofType" className="w-full border rounded-md py-2 px-3" onChange={handleChange} required />
        </div>
        <div className="mb-4">
          <label htmlFor="proofNo" className="block text-gray-700">Proof Number</label>
          <input type="text" id="proofNo" name="proofNo" className="w-full border rounded-md py-2 px-3" onChange={handleChange} required />
        </div>
        <div className="mt-6">
          <button type="submit" className="bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600">Register</button>
        </div>
      </form>
    </div>
  );
};

export default RegistrationForm;