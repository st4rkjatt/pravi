import React, { useState } from "react";

interface LoanFormState {
  loanType: string;
  loanAmount: number;
  loanApplyDate: string;
  interestRate: number;
  duration: number;
  // Additional fields for Education Loan
}
interface PersonalType {
  annualIncome: number;
  companyName: string;
  designation: string;
  totalExperience: number;
  currentCompany: string;
}
interface EducationType {
  courseFee: number;
  course: string;
  fatherName: string;
  fatherOccupation: string;
  annualIncomeFather: number;
}

const Dashboard: React.FC = () => {
  const [formData, setFormData] = useState<LoanFormState>({
    loanType: "",
    loanAmount: 0,
    loanApplyDate: "",
    interestRate: 0,
    duration: 5,
  });

  const [educationForm, setEducationForm] = useState<EducationType>({
    courseFee: 0,
    course: "",
    fatherName: "",
    fatherOccupation: "",
    annualIncomeFather: 0,
  });
  const [personalForm, setPersonalForm] = useState<PersonalType>({
    annualIncome: 0,
    companyName: "",
    designation: "",
    totalExperience: 0,
    currentCompany: "",
  });

  const [errors, setErrors] = useState<Partial<LoanFormState>>({});

  //   const validateForm = () => {
  //     const newErrors: Partial<LoanFormState> = {};

  //     // Validation logic for Account holder name (assuming it's common for all loan types)
  //     if (!formData.fatherName.match(/^[A-Za-z ]+$/)) {
  //       newErrors.fatherName = "Account holder name should contain only alphabets and space.";
  //     }

  //     // Validation logic for other common fields
  //     // if (!formData.loanAmount || formData.loanAmount <= 0) {
  //     //   newErrors.loanAmount = "Loan amount should be greater than zero.";
  //     // }

  //     // Add more validation logic for specific loan types (Educational, Personal/Home)
  //     // if (formData.loanType === LoanType.Educational) {
  //     //   if (!formData.courseFee || formData.courseFee <= 0) {
  //     //     newErrors.courseFee = "Course fee should be greater than zero.";
  //     //   }
  //     //   // Add more validation for educational loan fields
  //     // } else if (formData.loanType === LoanType.Personal || formData.loanType === LoanType.Housing) {
  //     //   if (!formData.annualIncomePH || formData.annualIncomePH <= 0) {
  //     //     newErrors.annualIncomePH = "Annual income should be greater than zero.";
  //     //   }
  //       // Add more validation for personal/home loan fields
  //     }

  // Other validation rules (e.g., loan apply date, duration, etc.)

  // setErrors(newErrors);

  // return Object.values(newErrors).every((error) => !error);
  //   };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    console.log(formData, "formData");
  };

  const handleChange = (
    e:
      | React.ChangeEvent<HTMLTextAreaElement | HTMLInputElement>
      | React.ChangeEvent<HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleChangeEducation = (
    e:
      | React.ChangeEvent<HTMLTextAreaElement | HTMLInputElement>
      | React.ChangeEvent<HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setEducationForm({
      ...educationForm,
      [name]: value,
    });
  };
  //------------------------ for education form ------------------------------------
  const handleSubmitLoanType = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    console.log(educationForm, "formDataLoan ttpe");
  };

  // -----------------personal load------------------
  const handleSubmitPersonLoan = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    console.log(personalForm, "personal");
  };

  const handleChangePersonal = (
    e:
      | React.ChangeEvent<HTMLTextAreaElement | HTMLInputElement>
      | React.ChangeEvent<HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setPersonalForm({
      ...personalForm,
      [name]: value,
    });
  };

  return (
    <>
      {/* --------------------education loan form=============================== */}
      <div className="max-w-screen-xl mx-auto bg-white p-6 mt-4 rounded-md shadow-md">
        <h1 className="text-2xl font-semibold mb-4 text-center">
          Loan Application
        </h1>
        <form onSubmit={handleSubmit}>
          <div className="grid grid-cols-6 gap-2">
            <div className="mb-4">
              <label className="block text-gray-700">Loan Type</label>
              <select
                className="w-full border rounded-md py-2 px-3"
                name="loanType"
                onChange={handleChange}
                required
              >
                <option selected disabled>
                  Select Loan Type
                </option>
                <option value="Education">Education</option>
                <option value="Personal">Personal/Home loan</option>
              </select>
            </div>

            <div className="mb-4">
              <label className="block text-gray-700">Loan Amount</label>
              <input
                type="number"
                className="w-full border rounded-md py-2 px-3"
                name="loanAmount"
                onChange={handleChange}
                required
              />
            </div>
            <div className="mb-4">
              <label className="block text-gray-700">Apply Date Of Loan</label>
              <input
                type="date"
                className="w-full border rounded-md py-2 px-3"
                name="loanApplyDate"
                onChange={handleChange}
                required
              />
            </div>
            <div className="mb-4">
              <label className="block text-gray-700">Rate Of Interest</label>
              <input
                type="number"
                className="w-full border rounded-md py-2 px-3"
                name="interestRate"
                onChange={handleChange}
                required
              />
            </div>

            <div>
              <label className="block mt-1 text-sm font-medium text-gray-900 dark:text-white">
                Duration Of Loan
              </label>
              <select
                id="countries"
                className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                name="duration"
                onChange={handleChange}
              >
                <option selected disabled>
                  Choose Duration of Loan
                </option>
                <option value="5">5 Years</option>
                <option value="10">10 Years</option>
                <option value="15">15 Years</option>
                <option value="20">20 Years</option>
              </select>
            </div>

            <div className="mt-6 text-center">
              <button
                type="submit"
                className="bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600"
              >
                Apply for Loan
              </button>
            </div>
          </div>
        </form>
      </div>

      {formData.loanType === "Education" && (
        <>
          <form onSubmit={handleSubmitLoanType}>
            <h1 className="text-2xl font-semibold my-4 text-center">
              Education Loan
            </h1>

            <div className="max-w-screen-sm mx-auto my-5">
              <div className="">
                <div className="mb-4">
                  <label className="block text-gray-700">Course Fee</label>
                  <input
                    type="number"
                    className="w-full border rounded-md py-2 px-3"
                    name="courseFee"
                    onChange={handleChangeEducation}
                    required
                  />
                  {/* {errors.loanAmount && <p className="text-red-500">{errors.loanAmount}</p>} */}
                </div>
                <div className="mb-4">
                  <label className="block text-gray-700">Course</label>
                  <input
                    type="text"
                    className="w-full border rounded-md py-2 px-3"
                    name="course"
                    onChange={handleChangeEducation}
                    required
                  />
                  {/* {errors.loanAmount && <p className="text-red-500">{errors.loanAmount}</p>} */}
                </div>
                <div className="mb-4">
                  <label className="block text-gray-700">Father Name</label>
                  <input
                    type="text"
                    className="w-full border rounded-md py-2 px-3"
                    name="fatherName"
                    onChange={handleChangeEducation}
                    required
                  />
                  {/* {errors.loanAmount && <p className="text-red-500">{errors.loanAmount}</p>} */}
                </div>
                <div className="mb-4">
                  <label className="block text-gray-700">
                    Father Occupation
                  </label>
                  <input
                    type="text"
                    className="w-full border rounded-md py-2 px-3"
                    name="fatherOccupation"
                    onChange={handleChangeEducation}
                    required
                  />
                  {/* {errors.loanAmount && <p className="text-red-500">{errors.loanAmount}</p>} */}
                </div>
                <div className="mb-4">
                  <label className="block text-gray-700">Annual Salary</label>
                  <input
                    type="number"
                    className="w-full border rounded-md py-2 px-3"
                    name="annualIncomeFather"
                    onChange={handleChangeEducation}
                    required
                  />
                  {/* {errors.loanAmount && <p className="text-red-500">{errors.loanAmount}</p>} */}
                </div>

                <div className="mt-6 text-center">
                  <button
                    type="submit"
                    className="bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600"
                  >
                    Apply for Education Loan
                  </button>
                </div>
              </div>
            </div>
          </form>
        </>
      )}

      {formData.loanType === "Personal" && (
        <form onSubmit={handleSubmitPersonLoan}>
          <h1 className="text-2xl font-semibold my-4 text-center">
            Personal/Home Loan
          </h1>

          <div className="max-w-screen-sm mx-auto my-5">
            <div className="">
              <div className="mb-4">
                <label className="block text-gray-700">Annual Income</label>
                <input
                  type="number"
                  className="w-full border rounded-md py-2 px-3"
                  name="annualIncome"
                  onChange={handleChangePersonal}
                  required
                />
                {/* {errors.loanAmount && <p className="text-red-500">{errors.loanAmount}</p>} */}
              </div>
              <div className="mb-4">
                <label className="block text-gray-700">Company Name</label>
                <input
                  type="text"
                  className="w-full border rounded-md py-2 px-3"
                  name="companyName"
                  onChange={handleChangePersonal}
                  required
                />
                {/* {errors.loanAmount && <p className="text-red-500">{errors.loanAmount}</p>} */}
              </div>
              <div className="mb-4">
                <label className="block text-gray-700">Designation</label>
                <input
                  type="text"
                  className="w-full border rounded-md py-2 px-3"
                  name="designation"
                  onChange={handleChangePersonal}
                  required
                />
                {/* {errors.loanAmount && <p className="text-red-500">{errors.loanAmount}</p>} */}
              </div>
              <div className="mb-4">
                <label className="block text-gray-700">Total Experience</label>
                <input
                  type="text"
                  className="w-full border rounded-md py-2 px-3"
                  name="totalExperiance"
                  onChange={handleChangePersonal}
                  required
                />
                {/* {errors.loanAmount && <p className="text-red-500">{errors.loanAmount}</p>} */}
              </div>
              <div className="mb-4">
                <label className="block text-gray-700">Current Company</label>
                <input
                  type="number"
                  className="w-full border rounded-md py-2 px-3"
                  name="currentCompany"
                  onChange={handleChangePersonal}
                  required
                />
                {/* {errors.loanAmount && <p className="text-red-500">{errors.loanAmount}</p>} */}
              </div>

              <div className="mt-6 text-center">
                <button
                  type="submit"
                  className="bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600"
                >
                  Apply for Personal/Home Loan
                </button>
              </div>
            </div>
          </div>
        </form>
      )}
    </>
  );
};

export default Dashboard;
