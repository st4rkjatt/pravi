import React from "react";

const LoanType = () => {
  return <></>;
};

export default LoanType;
